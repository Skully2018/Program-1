/*
    File name: animal.h
    Authors: Michael, Peyton, Dawson, Clayton
    Purpose: This is the data class
    Date: 09/23/2024
*/


#ifndef ANIMAL_H
#define ANIMAL_H

#include "text.h"

class animal
{
    private:
    int num;                //These are how many animals we have at one time
    string name;            //This is the animal's name. Ex) Tiger, Lion, or Bear... oh my
    text* description;      //This is where you can type in anything about the animal

    public:

    animal();                     //Default constructor
    animal(int, string, text*); //This is how you'll make an animal object
    ~animal();                    //Destuctor

    void displayAnimal(); //This will print out to the screen our animal
    void saveAnimals(ofstream& outFile);   //This will save our animals to a txt file

};
#endif