/*
    File name: Driver.cpp
    Authors: Michael, Peyton, Dawson, Clayton
    Purpose: This is the main file for our Zoo
    Date: 09/23/2024
*/

#include "exhibit.h"

using namespace std;

int menuChoice, numExhibits;
char* fileName;                     //This char ptr helps us get a proper filename

int main()
{
     
    cout << "Welcome to the Zoo management system. Please enter the amount of exhibits you wish to start with\n";
    cin >> numExhibits;
    
    while(numExhibits < 1){                                             //Gets our max num of exhibits and checks to make sure it isn't zero
        cout << "Please enter a valid amount of exhibits!\n";
        cin >> numExhibits;
    }

    exhibit* ptr = new exhibit(numExhibits);        //This is our array of exhibits

    do{
        cout << "\t1) Create a new exhibit\n";
        cout << "\t2) Delete an exhibit\n";
        cout << "\t3) Read from a file\n";
        cout << "\t4) Save to a file\n";
        cout << "\t5) Display the current exhibits\n";
        cout << "\t6) End the program\n";

        cin >> menuChoice;

        if(menuChoice < 1 || menuChoice > 6){
            cout << "\tPlease input a valid response.\n";
        }

        if(menuChoice == 1){
           ptr->addExhibit();       //Adds to our zoo
        }
        else if(menuChoice == 2){
            ptr->removeExhibit();   //Removes from our zoo
        }
        else if(menuChoice == 3){
            cout << "What's the name of the file?\n";       //Loads info from a file
            cin >> fileName;
            ptr->loadFromFile(fileName);
        }
        else if(menuChoice == 4){
            cout << "What's the name of the file?\n";       //Reads from a file
            cin >> fileName;
            ptr->saveToFile(fileName);
        }
        else if(menuChoice == 5){
           ptr->displayExhibits();                          //Prints the contents of our zoo to the screen
        }

    }while(menuChoice != 6);

    return 0;
}