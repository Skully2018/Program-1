/*
    File name: animal.cpp
    Authors: Michael, Peyton, Dawson, Clayton
    Purpose: This has the functions for animal.h
    Date: 09/23/2024
*/

#include "animal.h"
#include <fstream>

//Constructor with stuff
animal::animal(int num, string name, text* description)
{
    this->num = num;
    this->name = name;
    this->description = description;
}

//Destructor that culls the animals
animal::~animal()
{
    cout << "\nGoodbye " << this->name << "!\n";
    delete [] description;
}

//Prints to screen
void animal::displayAnimal()
{
    cout <<"\tOur animal is " << name << "\n";
    cout <<"\t\tDESCRIPTION\n";
    cout <<"------------------------------\n";
    description->displayText();
    cout << "\n";
}

//Saves to a txt file
void animal::saveAnimals(ofstream& outFile)
{
    outFile << num << endl;
    outFile << name << endl;
    outFile << description->getText() << endl;
}