/*
    Filename: exhibit.cpp
    Authors: Michael, Peyton, Dawson, Clayton
    Purpose: Holds functions for our storage class
*/

#include "exhibit.h"
#include <fstream>

exhibit::exhibit(int maxSize)
{
	exhibit** ptr = new exhibit*[maxSize];
    numExhibits = 0;
}

exhibit::~exhibit()
{
	for(int i = 0; i < numExhibits; i++){
		delete exArray[i];
	}
	delete [] exArray;
}

void exhibit::addExhibit()
{
    int tempNum;
    string tempName;
    char* tempDescription;

    if(maxSize == numExhibits){
        cout << "We've hit the capacity!\n";
    }
    else{
    cout << "ENTER THE NAME OF THE ANIMAL\n";
    cin >> tempName;
    cin.ignore();
    cout << "ENTER THE AMOUNT OF ANIMALS\n";
    cin >> tempNum;
    cin.ignore();
    cout << "ENTER THE DESCRIPTION\n";
    cin >> tempDescription;

    animal* ptr = new animal(tempNum, tempName, tempDescription);
    }

}

void exhibit::displayExhibits()
{
    if(numExhibits < 1){
		for(int i = 0; i < numExhibits; i++){
			exArray[i]->displayAnimal();
		}
    }
        else
        cout << "There's nothing here.\n";
}

void exhibit::loadFromFile(char *ptr)
{
    ifstream inFile(ptr);
    int tempNum;
    string tempName;
    char tempDescription[10000];

    if(numExhibits == maxSize){
        cout << "We're at max capacity!\n";
    }
    else{
        if(!inFile.is_open()){
		    cout << "Couldn't open the file.\n";
	    }
	    else{
		    while(!inFile.eof())
            {
                inFile >> tempNum;
                cin.ignore();
                inFile >> tempName;
                cin.ignore();
                inFile.getline(tempDescription,10000,"\n");
                text* desPtr = new text(tempDescription);

                animal* ptr = new animal(tempNum, tempName, tempDescription);
            }
            
            exArray[(numExhibits)+1] = ptr;

            numExhibits++;
        }
        inFile.close();
    }
}

void exhibit::removeExhibit()
{
    int userChoice;
	text* ptr;
		
	if(numExhibits >= 1)
    {
		displayExhibits();
		cout << "\nWhich animal would you like to remove?";
		cin >> userChoice;
			
		while(userChoice < 1 && userChoice > numExhibits){
			cout <<"\nInvaild input. Please try again.";
			cin >> userChoice;
		}
			
		ptr = exArray[userChoice-1];
		cout << "\n" << ptr->name << " was deleted.";
			
		delete [] exArray[userChoice-1];
			
		for(int i = userChoice - 1; i < numExhibits; i++){  // moves back the array elements - 1, starting after the chosen element to delete
			exArray[i] = exArray[i - 1];
		}
		numExhibits--;
	}
	else
		cout <<"\nHow are we gonna run a zoo without any animals!!";
}

void exhibit::saveToFile(char *ptr)
{
    ofstream outFile(ptr);
	
	for(int i = 0; i < numExhibits; i++){
		exArray[i]->saveAnimals(outFile);
	}
	outFile.close();
}