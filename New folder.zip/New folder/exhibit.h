/*
    File name: exhibit.h
    Authors: Michael, Peyton, Dawson, Clayton
    Purpose: Storage class for our Zoo
    Date: 09/23/2024
*/

#ifndef EXHIBIT_H
#define EXHIBIT_H

#include "animal.h"
#include "animal.cpp"

class exhibit
{
    private:

    animal** exArray;
    int maxSize, numExhibits, name;
    
    public:
    
	exhibit(int);
	~exhibit();
	void addExhibit();
	void displayExhibits();
	void loadFromFile(char* arr);
	void removeExhibit();
	void saveToFile(char* arr);
};

#endif