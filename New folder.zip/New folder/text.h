/*
    Filename: text.h
    Authors: Michael, Peyton, Dawson, Clayton
    Purpose: This class is really just to hold a description of our animals
*/

#ifndef TEXT_H
#define TEXT_H

#include <iostream>
#include <cstring>

using namespace std;

class text
{
	private:
	
	const char* textArray;
	int textLength;
        
	public:
	
	text(const char* ptr);      //Constructor
	~text();                    //Destructor
	void displayText() const;
	const char* getText() const;
	int getLength()const;
};
#endif