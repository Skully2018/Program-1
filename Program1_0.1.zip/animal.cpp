/*
    File name: animal.cpp
    Authors: Michael Lamberth (insert names)
    Purpose: This has the functions for animal.h
    Date: 09/23/2024
*/

#include "animal.h"

void animal::setNumAnimal(int num)
{
    numAnimals = num;
}

void animal::setType(string name)
{
    type = name;
}

//void setExhibitNum(string*, int)

int animal::getNumAnimal()
{
    return numAnimals;
}

string animal::getType()
{
    return type;
}