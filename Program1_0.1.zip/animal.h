/*
    File name: animal.h
    Authors: Michael Lamberth (insert your names here)
    Purpose: This is the data class
    Date: 09/23/2024
*/


#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
using namespace std;

class animal
{
    private:
    int numAnimals;         //These are how many animals we have at one time
    string type;            //This is the animal's type. Ex) Tiger, Lion, or Bear... oh my
    string* exhibitNum;     //This is a pointer that points to how many exhibits we have of a certain type of animal

    public:

    int getNumAnimal();     //Getter functions
    string getType();
    
    void setNumAnimal(int);     //Setter functions
    void setType(string);
    void setExhitbitNum(string*, int);
}

#endif