/*
    File name: Driver.cpp
    Authors: Michael Lamberth, (insert your names here)
    Purpose: This is the main file for our Zoo
    Date: 09/23/2024
*/

#include "exhibit.h"
#include "animal.h"
#include <iostream>
#include <fstream>


using namespace std;

int menuChoice;

int main()
{
    cout << "\tWelcome to the Zoo management system. Please enter into the menu below:\n";

    do{
        cout << "\t1) Create a new exhibit\n";
        cout << "\t2) Delete an exhibit\n";
        cout << "\t3) Read from a file\n";
        cout << "\t4) Save to a file\n";
        cout << "\t5) Display the current exhibits\n";
        cout << "\t6) End the program\n";

        cin >> menuChoice;

        if(menuChoice < 1 || menuChoice > 6){
            cout << "\tPlease input a valid response.\n";
        }

        if(menuChoice == 1){
            //Make a new exhibit
        }
        if else(menuChoice == 2){
            //Delete an exhibit
        }
        if else(menuChoice == 3){
            //Read from a file
        }
        if else(menuChoice == 4){
            //Save to a file
        }
        if else(menuChoice == 5){
            //Display the information of the zoo
        }

    }while(menuChoice != 6)

    return 0;
}