/*
    File name: exhibit.h
    Authors: Michael Lamberth (insert names)
    Purpose: Storage class for our Zoo
    Date: 09/23/2024
*/

#ifndef EXHIBIT_H
#define EXHIBIT_H

class Zoo
{
    private:

    animal* exhibitPtr;
    int maxZooSize;

    public:
    //constructor
    //destructor
    //Display or read out the information to the screen
    //Add an animal
    //Delete an animal
    //Save to file
    //Load from file
}

#endif