/*
    Filename: text.cpp
    Authors: Michael, Peyton, Dawson, Clayton
    Purpose: Here are our functions for our text class
*/

#include "text.h"

//Text constructor
text::text(const char* arr){
	textLength = strlen(arr);
	char* ptr = new char [textLength+1];
	strcpy(ptr, arr);
	this->textArray = ptr;
}

//text destructor
text::~text(){
	delete [] textArray;
	cout << "Text destructor: Released memory for textArray." << endl;
}

//Displays text	
void text::displayText() const{
	cout << textArray;
}

//Accessor for arrayText
const char* text::getText() const{
	return textArray;
}

//Accessor for textLength
int text::getLength() const{
	return textLength;
}